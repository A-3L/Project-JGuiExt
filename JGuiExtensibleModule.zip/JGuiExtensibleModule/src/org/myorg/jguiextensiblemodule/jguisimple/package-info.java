/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/package-info.java to edit this template
 */
@TemplateRegistrations({
    
@TemplateRegistration(
        folder = "Other",
        iconBase="org/myorg/jguiextensiblemodule/Archive.jpg",
        displayName = "#Simpletemplate_displayName",
        content = "Simple.form.template",
        description = "DescriptionSimple.html",
        scriptEngine="freemarker"),
@TemplateRegistration(
        folder = "Other",
        iconBase="org/myorg/jguiextensiblemodule/Archive.jpg",
        displayName = "#Simpletemplate_displayName",
        content = "Simple.java.template",
        description = "DescriptionSimple.html",
        scriptEngine="freemarker")
 })       
@NbBundle.Messages({ "Simpletemplate_displayName= JGuiSimple file"  })
        
package org.myorg.jguiextensiblemodule.jguisimple;

import org.netbeans.api.templates.TemplateRegistration;
import org.netbeans.api.templates.TemplateRegistrations;
import org.openide.util.NbBundle;

