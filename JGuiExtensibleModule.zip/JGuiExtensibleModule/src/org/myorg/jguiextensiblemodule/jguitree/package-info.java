/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/package-info.java to edit this template
 */
@TemplateRegistrations({
    

@TemplateRegistration(
        folder = "Other",
        iconBase="org/myorg/jguiextensiblemodule/Archive.jpg",
        displayName = "#Treetemplate_displayName",
        content = "Tree.form.template",
        description = "DescriptionTree.html",
        scriptEngine="freemarker"),
    
@TemplateRegistration(
        folder = "Other",
        iconBase="org/myorg/jguiextensiblemodule/Archive.jpg",
        displayName = "#Treetemplate_displayName",
        content = "Tree.java.template",
        description = "DescriptionTree.html",
        scriptEngine="freemarker")

})        
@NbBundle.Messages({"Treetemplate_displayName= JGuiTree file"  }) 
package org.myorg.jguiextensiblemodule.jguitree;

import org.netbeans.api.templates.TemplateRegistration;
import org.netbeans.api.templates.TemplateRegistrations;
import org.openide.util.NbBundle;

